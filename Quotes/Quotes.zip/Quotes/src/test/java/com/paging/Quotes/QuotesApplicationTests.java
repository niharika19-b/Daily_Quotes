package com.paging.Quotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
